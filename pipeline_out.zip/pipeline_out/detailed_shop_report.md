# Shop Drawing Detailed Report

Identified shop drawings: **37**
Currently buildable with approved design input: **4**

## Inventory
- 21: BLOCKED
- 30: BLOCKED
- 31: BLOCKED
- 32: BLOCKED
- 33: BLOCKED
- 34: BLOCKED
- 35: BLOCKED
- 36: BLOCKED
- 37: BUILDABLE
- 38: BLOCKED
- 41: BLOCKED
- 42: BLOCKED
- 43: BLOCKED
- 44: BUILDABLE
- 45: BUILDABLE
- 46: BUILDABLE
- 51: BLOCKED
- 52: BLOCKED
- 53: BLOCKED
- 54: BLOCKED
- 65: BLOCKED
- 22H: BLOCKED
- 23H: BLOCKED
- 24H: BLOCKED
- 25H: BLOCKED
- 26H: BLOCKED
- 27H: BLOCKED
- 28H: BLOCKED
- 29H: BLOCKED
- 39H: BLOCKED
- 40H: BLOCKED
- 49H: BLOCKED
- 50H: BLOCKED
- 373H: BLOCKED
- 374H: BLOCKED
- 375H: BLOCKED
- 376H: BLOCKED

## Reference vs generated JSON
- Reference drawings: 0
- Generated drawings: 4
- Status counts: {'EXTRA_GENERATED': 4}
- 429B37: **EXTRA_GENERATED**
- 429B44: **EXTRA_GENERATED**
- 429B45: **EXTRA_GENERATED**
- 429B46: **EXTRA_GENERATED**

## Group report
- Groups: 43
- Backmarks: 37

## Engineering boundary
Bolt counts and fabrication dimensions are only generated when present in approved design input. The system does not reverse-engineer missing design decisions from validation drawings.
